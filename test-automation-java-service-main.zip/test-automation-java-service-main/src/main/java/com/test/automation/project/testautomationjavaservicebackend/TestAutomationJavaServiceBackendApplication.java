package com.test.automation.project.testautomationjavaservicebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestAutomationJavaServiceBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestAutomationJavaServiceBackendApplication.class, args);
	}

}
